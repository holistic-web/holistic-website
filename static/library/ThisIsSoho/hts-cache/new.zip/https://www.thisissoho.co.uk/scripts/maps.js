

//function createMap(theaddress) {
//   // $("#homeslider").css("border-left", "8px solid #6baa4a");
//   //   $("#homeslider").gmap3(
//  { 
//   marker:{
//      address: "53 Chandos Place, london, WC2N 4HS, uk"
//    },
//  map: {
  
//  address:"53 Chandos Place, london, WC2N 4HS, uk",
//      options: {
          
//          zoom: 15,
//          mapTypeId: "style1",
//          mapTypeControlOptions: {
//              mapTypeIds: []
//          }
//      }
//  },
//      styledmaptype: {
//          id: "style1",
//          options: {
//              name: "Monmouth"
//          },
//          styles: [
//  {
//    "featureType": "landscape",
//    "stylers": [
//      { "visibility": "off" }
//    ]
//  },{
//    "featureType": "road.arterial",
//    "stylers": [
//      { "visibility": "on" },
//      { "color": "#ddc12c" }
//    ]
//  },{
//    "featureType": "landscape.man_made",
//    "elementType": "geometry.fill",
//    "stylers": [
//      { "visibility": "on" },
//      { "color": "#e8e8e9" }
//    ]
//  },{
//  },{
//    "featureType": "poi.park",
//    "elementType": "geometry.fill",
//    "stylers": [
//      { "color": "#e8e8e9" },
//      { "visibility": "on" }
//    ]
//  },{
//  },{
//    "featureType": "road.arterial",
//    "elementType": "labels.text.fill",
//    "stylers": [
//      { "visibility": "on" },
//      { "color": "#ffffff" }
//    ]
//  }
//]


//      }
  
//  }
//);
 
// }
 
//jQuery(function () {
//	//fixWidthMap('#homeslider', '#cccccc', '', 0, 0);
//	createMap('Regent Street, London, UK');
//});
